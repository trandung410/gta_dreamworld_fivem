Config = {}
Config.discordWebHookUrl = ''
Config.discordWebHookImage = ''
