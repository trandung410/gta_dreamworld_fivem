# 22/03/2020
- Fix for UI opening outside of houses.

# 12/05/2020
- Fix for UI not displaying first element in furniture config.

# 17/07/2020
- Update to auth/credentials system.

# 22/07/2020
- Potential fix for UI bugging out when opened.
  * Caused by init function being fired to the NUI element before it has loaded properly.
- Fix for nil error on startup.