# Dependencies
- ESX
- allhousing
- meta_libs (v1.1 or newer) [https://github.com/meta-hub/meta_libs/releases]

# Installation
- Place folder in resources.
- start allhousing_furni in server.cfg
-Please refer to credentials.lua for instructions on authorising this product. (The mod will not work correctly/at all while it hasn't been authorized.)