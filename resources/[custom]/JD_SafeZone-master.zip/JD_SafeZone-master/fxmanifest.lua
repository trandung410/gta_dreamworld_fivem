author 'JokeDevil'
description 'JD SafeZone (https://www.jokedevil.com)'
version '1.0.5'
url 'https://jokedevil.com'


-- Server Scripts
server_script 'server/server.lua'
server_script 'config.lua'

-- Client Scripts
client_script 'client/client.lua'
client_script 'config.lua'

game 'gta5'
fx_version 'bodacious'
